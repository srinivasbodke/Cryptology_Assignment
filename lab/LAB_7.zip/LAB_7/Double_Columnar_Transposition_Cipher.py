
def get_column_order(key):
    return sorted(range(len(key)),
                  key=lambda i: (key[i].upper(), i))


def encrypt(text, key):
    if not key:
        raise ValueError("Key cannot be empty")

    columns = len(key)
    order = get_column_order(key)

    ciphertext = ""

    for col in order:
        for i in range(col, len(text), columns):
            ciphertext += text[i]

    return ciphertext


def decrypt(ciphertext, key):
    if not key:
        raise ValueError("Key cannot be empty")

    columns = len(key)
    rows = (len(ciphertext) + columns - 1) // columns
    remainder = len(ciphertext) % columns

    grid = [[''] * columns for _ in range(rows)]

    position = 0
    order = get_column_order(key)

    for col in order:
        length = rows if remainder == 0 or col < remainder else rows - 1

        for row in range(length):
            grid[row][col] = ciphertext[position]
            position += 1

    plaintext = ""

    for row in grid:
        plaintext += ''.join(row)

    return plaintext


# Main program
message = input("Enter plaintext: ")

key1 = input("Enter first keyword: ")
key2 = input("Enter second keyword: ")

# Double encryption
first_encryption = encrypt(message, key1)
final_ciphertext = encrypt(first_encryption, key2)

print("After first encryption:", first_encryption)
print("Final encrypted text:", final_ciphertext)

# Double decryption
first_decryption = decrypt(final_ciphertext, key2)
original_text = decrypt(first_decryption, key1)

print("After first decryption:", first_decryption)
print("Original plaintext:", original_text)
