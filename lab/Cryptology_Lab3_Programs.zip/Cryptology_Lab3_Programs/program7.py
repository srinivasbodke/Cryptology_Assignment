#Prime number list operations
primes = [2, 3, 5, 7, 11]

print("First three elements:", primes[:3])
print("Last element:", primes[-1])

primes.append(13)
primes.extend([17, 19])

print("Updated list:", primes)
print("Total number of elements:", len(primes))

