#  Modular arithmetic
values = [29, 55, 78, -3, -29]

for value in values:
    print(f"{value} mod 26 = {value % 26}")

num = int(input("Enter an integer: "))
print(f"{num} mod 26 = {num % 26}")
