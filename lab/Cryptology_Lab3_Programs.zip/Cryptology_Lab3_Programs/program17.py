# Percentage frequency
text = "CRYPTOLOGYISINTERESTING"

frequency = {}
for ch in text:
    frequency[ch] = frequency.get(ch, 0) + 1

total = len(text)

for ch, count in frequency.items():
    percentage = (count / total) * 100
    print(f"{ch} : {count} -> {percentage:.2f}%")
