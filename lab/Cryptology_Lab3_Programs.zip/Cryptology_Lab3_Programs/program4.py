num = float(input("Enter a floating-point number: "))

print("Data type       :", type(num))
print("Absolute value  :", abs(num))
print("Rounded to 2 decimals:", round(num, 2))
