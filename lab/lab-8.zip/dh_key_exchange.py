# Diffie-Hellman Key Exchange

# Public parameters (small values for demonstration)
p = 23
g = 5

# Private keys chosen independently by Alice and Bob
alice_private = 6
bob_private = 15

# Public keys exchanged
alice_public = pow(g, alice_private, p)
bob_public = pow(g, bob_private, p)

# Each party calculates the shared secret
alice_secret = pow(bob_public, alice_private, p)
bob_secret = pow(alice_public, bob_private, p)

print("Public prime (p):", p)
print("Public base (g):", g)
print("Alice's public key:", alice_public)
print("Bob's public key:", bob_public)
print("Alice's shared secret:", alice_secret)
print("Bob's shared secret:", bob_secret)
print("Keys match:", alice_secret == bob_secret)
