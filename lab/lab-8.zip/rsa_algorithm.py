# RSA Algorithm: Key Generation, Encryption and Decryption

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    for d in range(1, phi):
        if (e * d) % phi == 1:
            return d
    raise ValueError("Modular inverse not found")

# Two small prime numbers (educational example)
p, q = 61, 53
n = p * q
phi = (p - 1) * (q - 1)

e = 17
if gcd(e, phi) != 1:
    raise ValueError("e must be coprime with phi")

d = mod_inverse(e, phi)
message = 65  # Message must be smaller than n

cipher = pow(message, e, n)
decrypted = pow(cipher, d, n)

print("Public key :", (e, n))
print("Private key:", (d, n))
print("Original message:", message)
print("Encrypted message:", cipher)
print("Decrypted message:", decrypted)
