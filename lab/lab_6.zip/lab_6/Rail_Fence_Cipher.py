def encrypt_rail_fence(text: str, rails: int) -> str:
    # 1. Create an empty grid matrix representing the fence rails
    # Filled with '\n' as placeholders
    fence = [['\n' for _ in range(len(text))] for _ in range(rails)]
    
    row, col = 0, 0
    moving_down = False
    
    # 2. Place characters onto the grid in a zigzag pattern
    for char in text:
        # Reverse direction when hitting top (0) or bottom rail
        if row == 0 or row == rails - 1:
            moving_down = not moving_down
            
        fence[row][col] = char
        col += 1
        row += 1 if moving_down else -1
        
    # 3. Collect characters row-by-row to construct the ciphertext
    ciphertext = []
    for r in range(rails):
        for c in range(len(text)):
            if fence[r][c] != '\n':
                ciphertext.append(fence[r][c])
                
    return "".join(ciphertext)

# --- User Input Section ---
print("-" * 30)
print("RAIL FENCE ENCRYPTION")
print("-" * 30)

# Ask user for plaintext message
user_message = input("Enter the message to encrypt: ")

# Ask user for the number of rails with safety validation
while True:
    try:
        user_rails = int(input("Enter the number of rails (Key >= 2): "))
        if user_rails >= 2:
            break
        print("Please enter a number greater than or equal to 2.")
    except ValueError:
        print("Invalid input. Please enter a whole number.")

# Run encryption
encrypted_result = encrypt_rail_fence(user_message, user_rails)

# Display Results
print("-" * 30)
print(f"Original Text: {user_message}")
print(f"Ciphertext:    {encrypted_result}")
print("-" * 30)

