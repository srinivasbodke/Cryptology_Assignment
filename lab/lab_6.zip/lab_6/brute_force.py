def brute_force_shift_cipher(ciphertext: str):
    # Ensure the ciphertext is handled uniformly in uppercase
    ciphertext = ciphertext.upper()
    print(f"Brute-forcing ciphertext: '{ciphertext}'\n")
    print(f"{'Key':<5} | {'Decrypted Plaintext'}")
    print("-" * 30)
    
    # Iterate through all 26 possible shift keys
    for key in range(26):
        plaintext = []
        for char in ciphertext:
            if char.isalpha():
                # Shift character backward in the alphabet by the current key value
                shifted = (ord(char) - ord('A') - key) % 26
                plaintext.append(chr(shifted + ord('A')))
            else:
                # Leave spaces and punctuation unaltered
                plaintext.append(char)
                
        print(f"{key:<5} | {''.join(plaintext)}")

# Execute the brute-force attack
brute_force_shift_cipher("MCI RWR WH")

