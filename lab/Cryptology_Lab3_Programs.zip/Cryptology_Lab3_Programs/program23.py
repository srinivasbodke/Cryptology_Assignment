# Client and server communication
# Run this file twice:
# 1. Start the server mode first.
# 2. Start client mode in another terminal.

import socket

HOST = "127.0.0.1"
PORT = 5000

mode = input("Enter mode (server/client): ").strip().lower()

if mode == "server":
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.bind((HOST, PORT))
        server.listen(1)
        print("Server waiting for connection...")
        conn, address = server.accept()

        with conn:
            print("Connected by:", address)
            data = conn.recv(1024).decode()
            print("Client:", data)

            reply = input("Server reply: ")
            conn.sendall(reply.encode())

elif mode == "client":
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.connect((HOST, PORT))

        message = input("Enter message: ")
        client.sendall(message.encode())

        reply = client.recv(1024).decode()
        print("Server:", reply)

else:
    print("Invalid mode. Enter server or client.")

    #strip() removes leading and trailing whitespace from the input.
    #socket.socket(socket.AF_INET, socket.SOCK_STREAM) is used to create a TCP socket. AF_INET indicates that the socket will use IPv4 addresses, and SOCK_STREAM indicates that it will be a TCP socket.
    #socket.sockket is a method that creates a new socket object. The parameters specify the address family (AF_INET for IPv4) and the socket type (SOCK_STREAM for TCP).
    #we can also name socket.socket as c, so we can write c = socket.socket(socket.AF_INET, socket.SOCK_STREAM) instead of socket.socket(socket.AF_INET, socket.SOCK_STREAM).
    #sendall() is a method that sends data to the connected socket. It takes a bytes-like object as an argument, so we use encode() to convert the string message to bytes before sending it.
    #we written only client.sendall(message.encode()) because we only need to send the message to the server, not receive any data from the server.
    #whatever we write in the input() function will be sent to the server as a message. The server will receive this message and print it to the console.
    #server reply is is done by code conn.sendall(reply.encode()) which sends the reply message to the client. The client will receive this message and print it to the console.