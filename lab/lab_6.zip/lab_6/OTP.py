def otp_encrypt(plaintext: str, key: str) -> bytes:
    plain_bytes = plaintext.encode('utf-8')
    key_bytes = key.encode('utf-8')
    # XOR the bytes together
    ciphertext_bytes = bytes(p ^ k for p, k in zip(plain_bytes, key_bytes))
    return ciphertext_bytes

def otp_decrypt(ciphertext_bytes: bytes, key: str) -> str:
    key_bytes = key.encode('utf-8')
    # XOR the ciphertext bytes with the key bytes to get original text
    decrypted_bytes = bytes(c ^ k for c, k in zip(ciphertext_bytes, key_bytes))
    return decrypted_bytes.decode('utf-8')

# 1. Get user input for the message
user_message = input("Enter the message to encrypt: ")

# 2. Get user input for the key with length validation
while True:
    user_key = input(f"Enter the secret key (must be at least {len(user_message)} characters long): ")
    if len(user_key) >= len(user_message):
        # Truncate the key if it's longer than the message to match perfect OTP rules
        user_key = user_key[:len(user_message)]
        break
    print(f"Error: Key is too short ({len(user_key)} characters). Please try again.")

# Run encryption and decryption
ciphertext = otp_encrypt(user_message, user_key)
decrypted = otp_decrypt(ciphertext, user_key)

# Display the output
print("\n--- Results ---")
print(f"Original Text:   {user_message}")
print(f"Used Key:        {user_key}")
print(f"Ciphertext(Hex): {ciphertext.hex()}")
print(f"Decrypted Text:  {decrypted}")

