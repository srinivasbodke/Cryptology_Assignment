# Prime numbers
import math

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, math.isqrt(n) + 1):
        if n % i == 0:
            return False
    return True

num = int(input("Enter a number: "))
print("Prime" if is_prime(num) else "Not prime")

start = int(input("Enter range start: "))
end = int(input("Enter range end: "))

primes = [n for n in range(start, end + 1) if is_prime(n)]
print("Prime numbers:", primes)
