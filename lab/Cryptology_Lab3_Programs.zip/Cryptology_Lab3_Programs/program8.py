# String slicing
message = "CRYPTOLOGY USING PYTHON"

print("Length:", len(message))
print("First five characters:", message[:5])
print("Last six characters:", message[-6:])
print("Characters from positions 3 to 8:", message[3:9])
print("Reverse:", message[::-1])

