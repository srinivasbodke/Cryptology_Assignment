
def get_column_order(key):
    return sorted(range(len(key)),
                  key=lambda i: (key[i].upper(), i))


def encrypt(plaintext, key):
    if not key:
        raise ValueError("Key cannot be empty")

    columns = len(key)
    order = get_column_order(key)

    ciphertext = ""

    for col in order:
        for i in range(col, len(plaintext), columns):
            ciphertext += plaintext[i]

    return ciphertext


def decrypt(ciphertext, key):
    if not key:
        raise ValueError("Key cannot be empty")

    columns = len(key)
    rows = (len(ciphertext) + columns - 1) // columns
    remainder = len(ciphertext) % columns

    grid = [[''] * columns for _ in range(rows)]

    position = 0
    order = get_column_order(key)

    for col in order:
        length = rows if remainder == 0 or col < remainder else rows - 1

        for row in range(length):
            grid[row][col] = ciphertext[position]
            position += 1

    plaintext = ""

    for row in grid:
        plaintext += ''.join(row)

    return plaintext


# Main program
message = input("Enter plaintext: ")
key = input("Enter keyword: ")

ciphertext = encrypt(message, key)
print("Encrypted text:", ciphertext)

plaintext = decrypt(ciphertext, key)
print("Decrypted text:", plaintext)
