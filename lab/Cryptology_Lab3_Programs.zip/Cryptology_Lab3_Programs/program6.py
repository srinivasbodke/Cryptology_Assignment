s = "HELLO"
print("Original string:", s)

try:
    s[0] = "h"
except TypeError as e:
    print("String error:", e)

L = [1, 2, 3, 4, 5]
print("Original list:", L)

L[0] = 10
L.append(6)
print("Modified list:", L)

print("Strings are immutable; lists are mutable.")