#  Remove spaces
message = "CRYPTOLOGY USING PYTHON"
result = message.replace(" ", "")
print("Without spaces:", result)
