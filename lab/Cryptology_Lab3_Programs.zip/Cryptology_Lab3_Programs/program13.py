# Plaintext preprocessing
message = input("Enter a message: ")
message = message.strip().upper().replace(" ", "")
print("Processed text:", message)

#strip() removes leading and trailing whitespace from the input message.
