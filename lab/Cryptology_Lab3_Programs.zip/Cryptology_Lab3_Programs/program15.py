#Character grouping with X padding
message = input("Enter a string: ").replace(" ", "")

padding = (-len(message)) % 5
message += "X" * padding

for i in range(0, len(message), 5):
    print(message[i:i + 5])

#-len(message) % 5 is used to calculate the number of padding characters needed to make the length of the message a multiple of 5.
#The message is then padded with "X" characters to make it a multiple of 5.
#The loop iterates through the padded string in steps of 5, printing each group of 5 characters.
# eg if size of message is 12, then padding = (-12) % 5 = 3, so 3 "X" characters are added to the end of the message to make its length 15, which is a multiple of 5.
#3 because 12 + 3 = 15, and 15 is the next multiple of 5 after 12.
#% is the modulo operator, which gives the remainder of a division operation. In this case, it is used to calculate how many characters are needed to make the length of the message a multiple of 5.